#pragma once

#include "Triangulation.h"


class reader
{
    
    public:
    reader();
    ~reader();
   
    void readFile1(Triangulation & triangulation);
    private:
};
