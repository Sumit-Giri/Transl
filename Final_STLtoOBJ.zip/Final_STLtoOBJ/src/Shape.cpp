#include"../headers/Shape.h"


Shape :: Shape()
{

}

Shape :: ~Shape()
{

}